--[[
  More Frequent Autosave Plus for Cyberpunk 2077
  CET mod – interval, smart skip, hotkey save, pause, profiles, RU/EN.

  Requires: Cyber Engine Tweaks (+ RED4ext)
  Install: bin\x64\plugins\cyber_engine_tweaks\mods\MoreFrequentAutosave\
]]

local MOD = "MoreFrequentAutosave"
local CONFIG_FILE = "config.json"

local defaults = {
    enabled = true,
    intervalSeconds = 120,
    minInterval = 45,
    maxInterval = 1800,
    skipCombat = true,
    skipScene = true,
    showIndicator = true,
    pauseMinutes = 0,
    profile = 2,
    language = "ru",          -- "ru" | "en"
    lastSaveClock = 0,
    lastSaveNote = "",
    saveCount = 0,
}

local L = {
    ru = {
        title = "Autosave Plus",
        status_on = "Статус: ВКЛ",
        status_off = "Статус: ВЫКЛ",
        btn_enable = "Включить мод",
        btn_disable = "Выключить мод",
        enable_box = "Автосохранения",
        interval = "Интервал: %d сек  (%.1f мин)",
        min_allowed = "Минимум: %d сек (защита FPS/диска)",
        profiles = "Профили:",
        presets = "Быстрые пресеты:",
        smart = "Умный пропуск:",
        skip_combat = "Не сейвить в бою",
        skip_scene = "Не сейвить в катсценах",
        show_status = "Показывать статус",
        apply = "Применить + Сохранить",
        force = "Сейв сейчас",
        pause5 = "Пауза 5 мин",
        pause10 = "Пауза 10 мин",
        resume = "Продолжить",
        last_none = "Ручных сейвов ещё не было",
        last_manual = "Последний ручной: %s",
        save_count = "Ручных сейвов: %d",
        paused_left = "ПАУЗА — осталось %d сек",
        lang = "Язык",
        lang_ru = "Русский",
        lang_en = "English",
        hotkey_hint = "Клавиши: CET → Bindings",
        as_on = "Автосейв каждые %d с (%.1f мин)",
        as_off = "Автосейв ВЫКЛ",
        as_paused = "Автосейв на паузе",
        mod_on = "Мод ВКЛЮЧЁН",
        mod_off = "Мод ВЫКЛЮЧЕН",
        resumed = "Автосейв возобновлён",
        paused5 = "Пауза 5 минут",
        paused10 = "Пауза 10 минут",
        skip_combat_ind = "Автосейв пауза (бой)",
        skip_scene_ind = "Автосейв пауза (катсцена)",
        cannot_save = "Сейчас нельзя сохранить",
        skip_scene_msg = "Пропуск: катсцена",
        skip_combat_msg = "Пропуск: бой",
        wait = "Подожди немного…",
        force_ok = "Ручной сейв запрошен",
        force_fallback = "Короткое окно автосейва (15с)",
        force_fail = "API сейва недоступен",
        prof_safe = "Безопасно (60с)",
        prof_normal = "Обычный (2м)",
        prof_rare = "Редко (5м)",
        prof_custom = "Свой",
    },
    en = {
        title = "Autosave Plus",
        status_on = "Status: ON",
        status_off = "Status: OFF",
        btn_enable = "Enable Mod",
        btn_disable = "Disable Mod",
        enable_box = "Enable Autosaves",
        interval = "Interval: %d sec  (%.1f min)",
        min_allowed = "Minimum: %d sec (FPS/disk protection)",
        profiles = "Profiles:",
        presets = "Quick presets:",
        smart = "Smart skip:",
        skip_combat = "Skip while in combat",
        skip_scene = "Skip cutscenes",
        show_status = "Show status messages",
        apply = "Apply + Save",
        force = "Save Now",
        pause5 = "Pause 5 min",
        pause10 = "Pause 10 min",
        resume = "Resume",
        last_none = "No manual saves yet",
        last_manual = "Last manual: %s",
        save_count = "Manual saves: %d",
        paused_left = "PAUSED – %d sec left",
        lang = "Language",
        lang_ru = "Русский",
        lang_en = "English",
        hotkey_hint = "Hotkeys: CET → Bindings",
        as_on = "Autosave every %d s (%.1f min)",
        as_off = "Autosave OFF",
        as_paused = "Autosave PAUSED",
        mod_on = "Mod ENABLED",
        mod_off = "Mod DISABLED",
        resumed = "Autosave resumed",
        paused5 = "Paused 5 minutes",
        paused10 = "Paused 10 minutes",
        skip_combat_ind = "Autosave paused (combat)",
        skip_scene_ind = "Autosave paused (cutscene)",
        cannot_save = "Cannot save now",
        skip_scene_msg = "Skipped: cutscene",
        skip_combat_msg = "Skipped: combat",
        wait = "Wait a moment…",
        force_ok = "Manual save requested",
        force_fallback = "Short autosave window (15s)",
        force_fail = "Save API unavailable",
        prof_safe = "Safe (60s)",
        prof_normal = "Normal (2m)",
        prof_rare = "Rare (5m)",
        prof_custom = "Custom",
    },
}

local function T(key, ...)
    local lang = (settings and settings.language) or "ru"
    local pack = L[lang] or L.ru
    local s = pack[key] or (L.en[key] or key)
    if select("#", ...) > 0 then
        return string.format(s, ...)
    end
    return s
end

local settings = {}
local showWindow = false
local pendingApply = false
local applyTimer = 0
local statusMessage = ""
local statusTimer = 0
local pauseUntil = 0
local indicatorText = ""
local lastForceSave = 0
local lastSkipState = nil

-- FPS: do not run heavy checks every frame
local skipAcc = 0
local SKIP_INTERVAL = 0.75   -- seconds between combat/scene checks
local statusAcc = 0

local profiles = {
    { key = "prof_safe",   sec = 60  },
    { key = "prof_normal", sec = 120 },
    { key = "prof_rare",   sec = 300 },
    { key = "prof_custom", sec = nil },
}

-------------------------------------------------
local function setStatus(msg, secs)
    if not settings.showIndicator and msg then
        -- still allow critical feedback in UI when window open
    end
    statusMessage = msg or ""
    statusTimer = secs or 3.0
end

local function loadConfig()
    local f = io.open(CONFIG_FILE, "r")
    if f then
        local content = f:read("*a")
        f:close()
        local ok, data = pcall(function() return json.decode(content) end)
        if ok and type(data) == "table" then settings = data else settings = {} end
    else
        settings = {}
    end
    for k, v in pairs(defaults) do
        if settings[k] == nil then settings[k] = v end
    end
    if settings.language ~= "en" and settings.language ~= "ru" then
        settings.language = "ru"
    end
    if settings.intervalSeconds < settings.minInterval then
        settings.intervalSeconds = settings.minInterval
    end
end

local function saveConfig()
    local ok, encoded = pcall(function() return json.encode(settings) end)
    if not ok then return false end
    local f = io.open(CONFIG_FILE, "w")
    if f then f:write(encoded); f:close(); return true end
    return false
end

local function player()
    local ok, p = pcall(function() return Game.GetPlayer() end)
    return ok and p or nil
end

local function inPreGame()
    local ok, v = pcall(function() return Game.GetSystemRequestsHandler():IsPreGame() end)
    return ok and v
end

local function inScene()
    local ok, v = pcall(function()
        local p = Game.GetPlayer()
        if not p then return false end
        local defs = Game.GetAllBlackboardDefs()
        local bb = Game.GetBlackboardSystem():GetLocalInstanced(p:GetEntityID(), defs.PlayerStateMachine)
        return bb:GetInt(defs.PlayerStateMachine.SceneTier) >= 3
    end)
    return ok and v
end

local function inCombat()
    local ok, v = pcall(function()
        local p = Game.GetPlayer()
        if not p then return false end
        if p.IsInCombat then return p:IsInCombat() end
        local defs = Game.GetAllBlackboardDefs()
        local bb = Game.GetBlackboardSystem():GetLocalInstanced(p:GetEntityID(), defs.PlayerStateMachine)
        local c = bb:GetInt(defs.PlayerStateMachine.Combat)
        return c and c > 0
    end)
    return ok and v
end

local function gameReady()
    if inPreGame() then return false end
    local p = player()
    if not p then return false end
    local ok, att = pcall(function() return p:IsAttached() end)
    return ok and att ~= false
end

local function applySettings()
    if not GameOptions then
        setStatus("GameOptions n/a")
        return
    end
    local paused = pauseUntil > 0 and (os.clock() < pauseUntil)
    if not settings.enabled or paused then
        pcall(function() GameOptions.Set("SaveConfig", "AutoSaveEnabled", "false") end)
        setStatus(paused and T("as_paused") or T("as_off"))
        return
    end
    local sec = math.floor(settings.intervalSeconds)
    if sec < settings.minInterval then sec = settings.minInterval end
    if sec > settings.maxInterval then sec = settings.maxInterval end
    settings.intervalSeconds = sec
    pcall(function()
        GameOptions.Set("SaveConfig", "AutoSavePeriod", tostring(sec))
        GameOptions.Set("SaveConfig", "AutoSaveEnabled", "true")
    end)
    setStatus(T("as_on", sec, sec / 60.0))
    print(string.format("[%s] ON every %d sec", MOD, sec))
end

local function applyAndSave()
    applySettings()
    saveConfig()
end

local function applyProfile(idx)
    settings.profile = idx
    local p = profiles[idx]
    if p and p.sec then settings.intervalSeconds = p.sec end
    applyAndSave()
end

local function tryForceSave()
    if not gameReady() then setStatus(T("cannot_save")); return false end
    if settings.skipScene and inScene() then setStatus(T("skip_scene_msg")); return false end
    if settings.skipCombat and inCombat() then setStatus(T("skip_combat_msg")); return false end
    if os.clock() - lastForceSave < 3 then setStatus(T("wait")); return false end

    local ok = pcall(function()
        local h = Game.GetSystemRequestsHandler()
        if h.RequestSaveGame then h:RequestSaveGame(); return end
        if h.QuickSave then h:QuickSave(); return end
        if h.SaveGame then h:SaveGame(); return end
        error("no save method")
    end)

    if not ok then
        ok = pcall(function()
            GameOptions.Set("SaveConfig", "AutoSaveEnabled", "true")
            GameOptions.Set("SaveConfig", "AutoSavePeriod", "15")
        end)
        if ok then
            setStatus(T("force_fallback"))
            pendingApply = true
            applyTimer = 20
            lastForceSave = os.clock()
            settings.lastSaveClock = os.time()
            settings.lastSaveNote = "force/short"
            settings.saveCount = (settings.saveCount or 0) + 1
            saveConfig()
            return true
        end
        setStatus(T("force_fail"))
        return false
    end

    lastForceSave = os.clock()
    settings.lastSaveClock = os.time()
    settings.lastSaveNote = "manual"
    settings.saveCount = (settings.saveCount or 0) + 1
    saveConfig()
    setStatus(T("force_ok"))
    return true
end

-- Throttled smart skip (not every frame → no FPS hit)
local function smartSkipTick()
    if not settings.enabled then
        if lastSkipState ~= nil then lastSkipState = nil; indicatorText = "" end
        return
    end
    if pauseUntil > 0 and os.clock() < pauseUntil then return end
    if not GameOptions then return end
    -- lightweight ready check only
    if inPreGame() then return end

    local skip, reason = false, nil
    if settings.skipScene and inScene() then
        skip, reason = true, "scene"
    elseif settings.skipCombat and inCombat() then
        skip, reason = true, "combat"
    end

    if skip then
        if lastSkipState ~= true then
            pcall(function() GameOptions.Set("SaveConfig", "AutoSaveEnabled", "false") end)
            lastSkipState = true
            indicatorText = (reason == "combat") and T("skip_combat_ind") or T("skip_scene_ind")
        end
    else
        if lastSkipState ~= false then
            pcall(function()
                GameOptions.Set("SaveConfig", "AutoSaveEnabled", "true")
                GameOptions.Set("SaveConfig", "AutoSavePeriod", tostring(math.floor(settings.intervalSeconds)))
            end)
            lastSkipState = false
            indicatorText = ""
        end
    end
end


local nsRegistered = false
local nsRetryAcc = 0

local function getNativeSettings()
    local ok, mod = pcall(function() return GetMod("nativeSettings") end)
    if ok and mod then return mod end
    if _G.nativeSettings then return _G.nativeSettings end
    return nil
end

local function registerNativeSettings()
    if nsRegistered then return true end
    local ns = getNativeSettings()
    if not ns then return false end

    local ok, err = pcall(function()
        local path = "/moreFrequentAutosave"
        if ns.pathExists and ns.pathExists(path) and ns.removeTab then
            pcall(function() ns.removeTab(path) end)
        end

        ns.addTab(path, "Autosave Plus")
        ns.addSubcategory(path .. "/general", "General / Основное")
        ns.addSubcategory(path .. "/smart", "Smart skip / Умный пропуск")
        ns.addSubcategory(path .. "/lang", "Language / Язык")

        ns.addSwitch(path .. "/general",
            "Enable mod / Включить мод",
            "Master switch for autosave control",
            settings.enabled, defaults.enabled,
            function(state)
                settings.enabled = state
                applyAndSave()
            end)

        ns.addRangeInt(path .. "/general",
            "Interval (seconds) / Интервал (сек)",
            "How often the game autosaves. Minimum 45s.",
            settings.minInterval, settings.maxInterval, 15,
            settings.intervalSeconds, defaults.intervalSeconds,
            function(value)
                settings.intervalSeconds = value
                settings.profile = 4
                applyAndSave()
            end)

        ns.addSelectorString(path .. "/general",
            "Profile / Профиль",
            "Quick interval presets",
            { "Safe 60s", "Normal 2m", "Rare 5m", "Custom" },
            settings.profile, defaults.profile,
            function(value)
                settings.profile = value
                local map = { 60, 120, 300, nil }
                if map[value] then
                    settings.intervalSeconds = map[value]
                end
                applyAndSave()
            end)

        if ns.addButton then
            ns.addButton(path .. "/general",
                "Force Save / Сохранить сейчас",
                "Request a save now (best-effort)",
                "Save",
                45,
                function()
                    tryForceSave()
                end)

            ns.addButton(path .. "/general",
                "Pause 5 min / Пауза 5 мин",
                "Temporarily disable autosave",
                "Pause",
                45,
                function()
                    pauseUntil = os.clock() + 5 * 60
                    settings.pauseMinutes = 5
                    applySettings()
                    saveConfig()
                    setStatus(T("paused5"))
                end)
        end

        ns.addSwitch(path .. "/smart",
            "Skip combat / Не сейвить в бою",
            "Disable engine autosave while in combat",
            settings.skipCombat, defaults.skipCombat,
            function(state)
                settings.skipCombat = state
                saveConfig()
            end)

        ns.addSwitch(path .. "/smart",
            "Skip cutscenes / Не сейвить в катсценах",
            "Disable engine autosave during cutscenes",
            settings.skipScene, defaults.skipScene,
            function(state)
                settings.skipScene = state
                saveConfig()
            end)

        ns.addSwitch(path .. "/smart",
            "Status messages / Сообщения статуса",
            "Show status texts in the CET window",
            settings.showIndicator, defaults.showIndicator,
            function(state)
                settings.showIndicator = state
                saveConfig()
            end)

        ns.addSelectorString(path .. "/lang",
            "UI Language / Язык интерфейса",
            "Language for the CET overlay window",
            { "Русский", "English" },
            settings.language == "en" and 2 or 1,
            1,
            function(value)
                settings.language = (value == 2) and "en" or "ru"
                saveConfig()
            end)
    end)

    if ok then
        nsRegistered = true
        print("[" .. MOD .. "] Native Settings: tab 'Autosave Plus' OK")
        return true
    end
    print("[" .. MOD .. "] Native Settings error: " .. tostring(err))
    return false
end

registerForEvent("onInit", function()
    loadConfig()
    pendingApply = true
    applyTimer = 1.5
    if not registerNativeSettings() then
        print("[" .. MOD .. "] Native Settings not ready – retrying in background")
    end
    print("[" .. MOD .. "] initialized")
end)

registerForEvent("onUpdate", function(delta)
    if not delta or delta <= 0 then return end
    if delta > 1.0 then delta = 1.0 end

    -- Native Settings late load
    if not nsRegistered then
        nsRetryAcc = nsRetryAcc + delta
        if nsRetryAcc >= 1.0 then
            nsRetryAcc = 0
            registerNativeSettings()
        end
    end

    if pendingApply then
        applyTimer = applyTimer - delta
        if applyTimer <= 0 then
            pendingApply = false
            applySettings()
        end
    end

    if statusTimer > 0 then
        statusTimer = statusTimer - delta
        if statusTimer <= 0 then statusMessage = "" end
    end

    if pauseUntil > 0 and os.clock() >= pauseUntil then
        pauseUntil = 0
        settings.pauseMinutes = 0
        applySettings()
        setStatus(T("resumed"))
        saveConfig()
    end

    -- FPS-friendly: smart skip at most ~1.3 times per second
    skipAcc = skipAcc + delta
    if skipAcc >= SKIP_INTERVAL then
        skipAcc = 0
        if settings.enabled and (settings.skipCombat or settings.skipScene) then
            smartSkipTick()
        end
    end
end)

-- Window stays available while CET overlay is open.
-- Also openable via hotkey "More Frequent Autosave: Open Settings"
registerForEvent("onOverlayOpen", function()
    showWindow = true
end)
registerForEvent("onOverlayClose", function()
    showWindow = false
    saveConfig()
end)

registerForEvent("onDraw", function()
    if not showWindow then return end

    ImGui.SetNextWindowSize(430, 520, ImGuiCond.FirstUseEver)
    if ImGui.Begin(T("title"), true) then
        -- Language row
        ImGui.Text(T("lang") .. ":")
        ImGui.SameLine()
        if ImGui.Button(T("lang_ru") .. "##ru", 90, 24) then
            settings.language = "ru"
            saveConfig()
        end
        ImGui.SameLine()
        if ImGui.Button(T("lang_en") .. "##en", 90, 24) then
            settings.language = "en"
            saveConfig()
        end
        ImGui.Separator()

        if settings.enabled then
            ImGui.TextColored(0.3, 1.0, 0.4, 1.0, T("status_on"))
            if ImGui.Button(T("btn_disable"), 200, 32) then
                settings.enabled = false
                applyAndSave()
                setStatus(T("mod_off"))
            end
        else
            ImGui.TextColored(1.0, 0.35, 0.35, 1.0, T("status_off"))
            if ImGui.Button(T("btn_enable"), 200, 32) then
                settings.enabled = true
                applyAndSave()
                setStatus(T("mod_on"))
            end
        end

        ImGui.Spacing()
        local en, ch = ImGui.Checkbox(T("enable_box"), settings.enabled)
        if ch then settings.enabled = en; applyAndSave() end

        ImGui.Spacing()
        ImGui.Text(T("interval", settings.intervalSeconds, settings.intervalSeconds / 60.0))
        ImGui.TextDisabled(T("min_allowed", settings.minInterval))

        local newVal, changed = ImGui.SliderInt("##sec", settings.intervalSeconds, settings.minInterval, settings.maxInterval)
        if changed then
            settings.intervalSeconds = newVal
            settings.profile = 4
        end

        ImGui.Spacing()
        ImGui.Text(T("profiles"))
        for i, p in ipairs(profiles) do
            if ImGui.Button(T(p.key) .. "##prof" .. i, 95, 24) then applyProfile(i) end
            if i < #profiles then ImGui.SameLine() end
        end

        ImGui.Spacing()
        ImGui.Text(T("presets"))
        local presets = { 60, 90, 120, 180, 300, 600 }
        for i, sec in ipairs(presets) do
            local label = (sec % 60 == 0) and (string.format("%dm", sec / 60)) or (sec .. "s")
            if ImGui.Button(label .. "##p" .. i, 48, 24) then
                settings.intervalSeconds = math.max(settings.minInterval, sec)
                settings.profile = 4
                applyAndSave()
            end
            if i < #presets then ImGui.SameLine() end
        end

        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Text(T("smart"))
        local sc, c1 = ImGui.Checkbox(T("skip_combat"), settings.skipCombat)
        if c1 then settings.skipCombat = sc; saveConfig() end
        local ss, c2 = ImGui.Checkbox(T("skip_scene"), settings.skipScene)
        if c2 then settings.skipScene = ss; saveConfig() end
        local si, c3 = ImGui.Checkbox(T("show_status"), settings.showIndicator)
        if c3 then settings.showIndicator = si; saveConfig() end

        ImGui.Spacing()
        if ImGui.Button(T("apply"), 150, 28) then applyAndSave() end
        ImGui.SameLine()
        if ImGui.Button(T("force"), 150, 28) then tryForceSave() end

        ImGui.Spacing()
        if ImGui.Button(T("pause5"), 110, 26) then
            pauseUntil = os.clock() + 5 * 60
            settings.pauseMinutes = 5
            applySettings(); saveConfig(); setStatus(T("paused5"))
        end
        ImGui.SameLine()
        if ImGui.Button(T("pause10"), 110, 26) then
            pauseUntil = os.clock() + 10 * 60
            settings.pauseMinutes = 10
            applySettings(); saveConfig(); setStatus(T("paused10"))
        end
        ImGui.SameLine()
        if ImGui.Button(T("resume"), 90, 26) then
            pauseUntil = 0
            settings.pauseMinutes = 0
            applyAndSave(); setStatus(T("resumed"))
        end

        ImGui.Spacing()
        ImGui.Separator()
        local last = settings.lastSaveClock or 0
        if last > 0 then
            ImGui.Text(T("last_manual", os.date("%H:%M:%S", last)))
            ImGui.TextDisabled(settings.lastSaveNote or "")
        else
            ImGui.TextDisabled(T("last_none"))
        end
        ImGui.Text(T("save_count", settings.saveCount or 0))

        if pauseUntil > 0 and os.clock() < pauseUntil then
            ImGui.TextColored(1.0, 0.7, 0.2, 1.0, T("paused_left", math.floor(pauseUntil - os.clock())))
        end
        if indicatorText ~= "" then
            ImGui.TextColored(1.0, 0.6, 0.3, 1.0, indicatorText)
        end
        if statusMessage ~= "" and settings.showIndicator then
            ImGui.TextColored(0.4, 1.0, 0.5, 1.0, statusMessage)
        end

        ImGui.Spacing()
        ImGui.TextDisabled(T("hotkey_hint"))
    end
    ImGui.End()
end)

registerHotkey("MFA_OpenSettings", "More Frequent Autosave: Open Settings", function()
    showWindow = not showWindow
end)
registerHotkey("MFA_ForceSave", "More Frequent Autosave: Force Save", function() tryForceSave() end)
registerHotkey("MFA_Toggle", "More Frequent Autosave: Toggle ON/OFF", function()
    settings.enabled = not settings.enabled
    applyAndSave()
end)
registerHotkey("MFA_Pause5", "More Frequent Autosave: Pause 5 min", function()
    pauseUntil = os.clock() + 5 * 60
    applySettings()
    setStatus(T("paused5"))
end)

function MoreFrequentAutosave_SetInterval(sec)
    local v = tonumber(sec)
    if not v then return end
    v = math.max(settings.minInterval, math.min(settings.maxInterval, math.floor(v)))
    settings.intervalSeconds = v
    settings.profile = 4
    applyAndSave()
end

function MoreFrequentAutosave_Toggle(state)
    if state == nil then settings.enabled = not settings.enabled
    else settings.enabled = not not state end
    applyAndSave()
end

function MoreFrequentAutosave_ForceSave() tryForceSave() end

print("[" .. MOD .. "] ready")
