========================================
  More Frequent Autosave Plus
========================================

ТРЕБОВАНИЯ:
  - RED4ext
  - Cyber Engine Tweaks
  - Native Settings UI (рекомендуется)
    https://www.nexusmods.com/cyberpunk2077/mods/3518

ГДЕ НАСТРОЙКИ:
  1) ESC → Settings → Mods → "Autosave Plus"  (Native Settings)
  2) CET overlay → окно "Autosave Plus"
  3) Хоткей "More Frequent Autosave: Open Settings"

УСТАНОВКА:
  MoreFrequentAutosave →
  bin\x64\plugins\cyber_engine_tweaks\mods\

Вкладка Native Settings:
  - Enable mod
  - Interval (seconds)
  - Profile (Safe / Normal / Rare / Custom)
  - Force Save / Pause 5 min
  - Skip combat / Skip cutscenes
  - UI Language RU/EN
========================================
